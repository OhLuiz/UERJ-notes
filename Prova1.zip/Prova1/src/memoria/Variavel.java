/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package memoria;


/**
 * Classe que representa uma variável a ser armazenada em memória e utilizada
 * em operações.
 *
 * @author clique
 */
public class Variavel {
    /**
     * Nome associado à variável.
     */
    private final String nome;
    /**
     * Valor armazenado na variável.
     */
    private double valor;

    /**
     * Construtor básico. Toda variável deve ter nome e valor.
     */
    public Variavel(String nome, double valor) {
        this.nome = nome.toLowerCase();
        this.valor = valor;
    }

    public String getNome() {
        return nome;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Variavel other = (Variavel) obj;
        return this.nome.equals(other.nome);
    }
    
    /**
     * Retorn a posição do vetor de variáveis onde a variável de nome passado se
     * encontra.
     * 
     * @param variaveis vetor a ser buscado.
     * @param nome nome da variável a ser buscada.
     * @return a posição da variável caso seja encontrada e -1, caso contrário.
     */
    public static int busca(Variavel[] variaveis, String nome){
        nome = nome.toLowerCase();
        for (int i = 0; i < variaveis.length; i++) 
            if (variaveis[i] != null && nome.equals(variaveis[i].getNome()))
                return i;
        return -1;
    }
    
}
