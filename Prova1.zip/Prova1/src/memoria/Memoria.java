/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package memoria;

/**
 * Classe que representa uma memória de computador, armazenando variáveis e seus
 * respectivos valores.
 *
 * @author clique
 */
public class Memoria {
    /**
     * Quantidade máxima de variáveis.
     */
    private final int maxVariaveis;
    /**
     * Quantidade atual de variáveis.
     */
    private int quantVariaveis;
    /**
     * Vetor de variáveis.
     */
    private final Variavel[] variaveis;
    
    
    /**
     * Inicializa uma nova memória com a quantidade passada de variáveis.
     * 
     * @param maxVariaveis quantidade máxima de variáveis na memória.
     */
    public Memoria(int maxVariaveis) {
        this.maxVariaveis = maxVariaveis;
        this.quantVariaveis = 0;
        this.variaveis = new Variavel[maxVariaveis];
    }
    
    
    /**
     * Imprime na tela, e pula uma linha, o valor da variável com o nome
     * passsado.
     * 
     * @param nomeVariavel nome da variável a ser impressa na tela.
     * @return retorna verdadeiro caso a variável esteja na memória e falso caso
     * contrário.
     */
    public boolean imprime(String nomeVariavel){
        nomeVariavel = nomeVariavel.toLowerCase();
        int pos = Variavel.busca(variaveis,nomeVariavel);
        if(pos == -1) return false;
        System.out.println(variaveis[pos].getValor());
        return true;
    }

    /**
     * Retorna a referência da variável que está na posição i.
     * 
     * @param i posição da variável.
     * @return a referência da variável que está na posição i.
     */
    public Variavel getVariavel(int i) {
        return variaveis[i];
    }

    /**
     * Retorna a referência da variável cujo nome foi passado.
     * 
     * @param nome nome da variável
     * @return a referência da variável ou nulo, caso não esteja na memória.
     */
    public Variavel getVariavel(String nome) {
        nome = nome.toLowerCase();
        return variaveis[Variavel.busca(variaveis, nome)];
    }
    
    /**
     * Retorna verdadeiro caso a variável com o nome passado esteja na memória.
     * 
     * @param nome nome da variável
     * @return verdadeiro caso a variável com o nome passado esteja na memória e
     * falso caso contrário.
     */
    public boolean variavelJaExiste(String nome){
        nome = nome.toLowerCase();
        return Variavel.busca(variaveis,nome) != -1;
    }
    
    /**
     * Retorna verdadeiro caso não haja nenhum espaço vazio na memória.
     * 
     * @return verdadeiro caso não haja nenhum espaço vazio na memória e falso 
     * caso contrário.
     */
    public boolean estaCheio(){
        return quantVariaveis == maxVariaveis;
    }
}
