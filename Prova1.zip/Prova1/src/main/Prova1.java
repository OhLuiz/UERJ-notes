/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import memoria.Memoria;
import java.util.Arrays;
import java.util.Scanner;
import operacoes.Operacao;
import utilitarios.Utilitarios;

/**
 * Esta classe contém toda a lógica de interação com o usuário.
 *
 * @author clique
 */
public class Prova1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        Memoria calculadora = new Memoria(10);
        String comando[];//tipoComando pertence a {"atribuicao", "calculo","impressao"}
        String tipoComando;//tipoComando pertence a {"atribuicao", "calculo","impressao"}
        String atual;
        
        System.out.println("BEM VINDO À CALCULADORA ARITMÉTICA");
        System.out.println("AQUI É POSSÍVEL ARMAZENAR VALORES EM VARIAVEIS,"
                + " FAZER CÁLCULOS COM ELAS E MOSTRÁ-LAS NA TELA.");
        System.out.println("TODAS AS VARIÁVEIS, OPERADORES E VALORES ENVOLVIDOS"
                + " DEVEM SER SEPARADOS POR ESPAÇO EM BRANCO.");
        System.out.println("O COMANDO SAIR SAI DO PROGRAMA");
        
        while (true){
            System.out.print(">>>");
            comando = Utilitarios.cadaValor(teclado.nextLine());
            int i = 0;
            
            atual = comando[i];
            
            if(atual.toLowerCase().equals("sair")){
                break;
            }
            else if(comando.length == 1){
                tipoComando = "impressao";
            }
            else if(comando[i+1].equals("=")){
                tipoComando = "atribuicao";
                i++;
            }
            else if(Utilitarios.eDouble(atual)){
                tipoComando = "naoConhecido";
                System.out.println(atual);
            }
            else tipoComando = "calculo";
            
            switch(tipoComando){
                case "naoConhecido":
                    executaNaoConhecido();
                    break;
                case "impressao":
                    executaImpressao(calculadora, comando);
                    break;
                case "calculo":
                    System.out.println(executaCalculo(calculadora, comando));
                    break;
                case "atribuicao":
                    executaAtribuicao(calculadora, comando);
                    break;
            }
            
        }
    }

    private static void executaNaoConhecido() {
        System.out.println("Comando não reconhecido. Espera-se:\n"
                + "--- uma variável apenas;\n"
                + "--- uma variável seguida de '=' e depois de um valor/calculo;\n"
                + "--- um cálculo apenas");
    }

    private static void executaImpressao(Memoria calculadora, String[] comando) {
        if(!calculadora.imprime(comando[0]))
            System.out.println("A variável "+comando[0]+" ainda não foi criada");
    }

    private static void executaAtribuicao(Memoria calculadora, String[] comando) {
        if(!calculadora.variavelJaExiste(comando[0]) && calculadora.estaCheio()){
            System.out.println("Não é possível criar mais variáveis. "
                                + "O limite foi atingido");
            return;
        }
        
        String var = comando[0];
        if(comando.length == 3){
            if(Utilitarios.eDouble(comando[2])){
                /**
                 * O método atribui recebe um nome de variável e um double. 
                 * 
                 * Ele então converte este nome para minúsculo e,caso o nome já
                 * pertença à uma variável na calculadora, apenas
                 * altera o valor contido nele para o valor passado. Caso a
                 * variável não pertença à calculadora, cria uma nova
                 * variável no próximo espaço sobrando com este nome e coloca o
                 * valor passado nele. Caso não pertença e não haja espaço
                 * sobrando, apenas lança um erro.
                 * 
                 * throw new RuntimeException("O limite de variáveis foi atingido");
                 * 
                 */
                calculadora.atribui(comando[0], 
                                    Double.parseDouble(comando[2]));
                return;
            }
            if(!calculadora.variavelJaExiste(comando[2])){
                System.out.println("Variável "+comando[2]+ " não foi definida.");
                return;
            }
            /**
             * O método atribui recebe dois nomes de variáveis. 
             * 
             * Ele então converte estes nomes para minúsculo e, caso a variável
             * com o nome2 não pertença à calculador, lança um erro:
             * 
             * throw new RuntimeException("Variável "+nome2+" não existe");
             * 
             * Caso o nome1 já pertença à uma variável na calculadora, apenas
             * altera o valor contido nele para o valor contido na variável de
             * nome2. Caso a variável não pertença à calculadora, cria uma nova
             * variável no próximo espaço sobrando com este nome e coloca o
             * valor de nome2 nele. Caso não pertença e não haja espaço
             * sobrando, apenas lança um erro.
             * 
             * throw new RuntimeException("O limite de variáveis foi atingido");
             * 
             */
            calculadora.atribui(comando[0], comando[2]);
        }else{
            comando = Arrays.copyOfRange(comando, 2, comando.length);
            double res = executaCalculo(calculadora, comando);
            if(res != Double.NaN){
                //VEJA LINHA 100
                calculadora.atribui(var, res);
            }
        }
    }

    private static double executaCalculo(Memoria calculadora, String[] comando) {
        if(Utilitarios.getOperador(comando).equals("")){
            System.out.println("Cálculo inválido. Somente são aceitos cálculos "
                                + "utilizando apenas um operador");
            return Double.NaN;
        }
        
        Operacao op = Operacao.getOperacao(Utilitarios.getOperador(comando), 
                                           Utilitarios.getOperandos(calculadora,comando));
        
        if(op == null){
            System.out.println("Operação não implementada. Somente são aceitas"
                                + "as operações de soma(+), subtração(-), "
                                + "multiplicação(x) e divisão(/)");
            return Double.NaN;
        }
        
        return op.executa();
        
    }
}
