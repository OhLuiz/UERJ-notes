/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utilitarios;

import memoria.Memoria;
import memoria.Variavel;

/**
 * Classe que contém métodos estáticos úteis.
 *
 * @author clique
 */
public class Utilitarios {

    /**
     * Retorna verdadeiro se for possível converter test para double.
     * 
     * @param test String a ser testada
     * @return Retorna verdadeiro se for possível converter test para double.
     */
    public static boolean eDouble(String test) {
        double res;
        try {
            res = Double.valueOf(test);
        } catch (NumberFormatException ex) {
            res = Double.NaN;
        }
        return !Double.isNaN(res);
    }
    
    /**
     * Retorna verdadeiro se for possível converter test para inteiro.
     * 
     * @param test String a ser testada
     * @return Retorna verdadeiro se for possível converter test para inteiro.
     */
    public static boolean eInt(String test) {
        int res;
        try {
            res = Integer.valueOf(test);
        } catch (NumberFormatException ex) {
            res = Integer.MIN_VALUE;
        }
        return res != Integer.MIN_VALUE;
    }
    
    /**
     * Retorna verdadeiro se o double passado é um inteiro.
     * 
     * @param d double a ser testado
     * @return Retorna verdadeiro se o double passado é um inteiro.
     */
    public static boolean eInt(double d) {
        return Math.round(d) == Math.floor(d);
    }

    /**
     * Recebe uma lista 'comando' de palavras que representa os nomes das
     * variáveis e operadores de um cálculo. Caso os nomes sejam de variáveis 
 armazenadas na 'calculadora', retorna as variáveis correspondentes. Caso
 alguma das variáveis referenciadas não exista na 'calculadora', retorna
 null.
 
 ex. comando = {"a","+","b","+","c"}
     calculadora = Memoria(   Variavel("a",15.0),
                                  Variavel("b",7.2),
                                  Variavel("c",2.1),
                                  Variavel("azul",13.4) )
 
      retorno: {Variavel("a",15.0),
                Variavel("b",7.2),
                Variavel("c",2.1)} 
     * 
     * @param calculadora Memoria onde estão as variáveis.
     * @param comando Lista de palavras com os nomes de variáveis e operadores 
     * de um cálculo.
     * @return Retorna uma lista com as variáveis do cálculo ou null caso haja
     * algum nome que não referencia ninguém na 'calculadora'.
     */
    public static Variavel[] getOperandos(Memoria calculadora, String[] comando) {
    }

    /**
     * Recebe uma lista 'comando' de palavras que representa os nomes das
     * variáveis e operadores de um cálculo. Caso os operadores sejam todos
     * iguais, retorna este operados. Caso sejam diferentes, retorna uma String
     * vazia.
     * 
     * ex. comando = {"a","+","b","+","c"}
     * retorna "+"
     * 
     * ex. comando = {"a","+","b","-","c"}
     * retorn ""
     * 
     * @param comando Lista de palavras com os nomes de variáveis e operadores 
     * de um cálculo.
     * @return retorna o único operador utitlizado ou null caso haja mais de um.
     */
    public static String getOperador(String[] comando) {
    }

    /**
     * Separa a linha em palavras sem espaços sobrando antes ou depois e
     * retorna-as como um vetor.
     * 
     * @param linha String composta por palavras.
     * @return Vetor com cada palavra separada, sem espaços em branco.
     */
    public static String[] cadaValor(String linha) {
        String[] res = linha.split(" ");
        for (int i = 0; i < res.length; i++) {
            res[i] = res[i].trim();
        }
        return res;
    }
    
}
