/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package operacoes;

import memoria.Variavel;
import utilitarios.Utilitarios;

/**
 * Classe que implementa a operação de soma.
 * 
 * @author clique
 */
public class Multiplicacao extends Operacao {
    
    /**
     * Tabuada que contém as multiplicações de todos os valores entre 0 e 9,
     * utilizados na multiplicação eficiente.
     * 
     * ex. tabuada[5][7] = 35               //(5 * 7)
     * ex. tabuada[2][3] = 6                //(2 * 3)
     * ex. tabuada[9][9] = 81               //(9 * 9)
     */
    private final int tabuada[][];
    {
        tabuada = new int[10][10];
        for (int i = 0; i < tabuada.length; i++) 
            for (int j = 0; j < tabuada.length; j++) 
                tabuada[i][j] = (i)*(j);
    }

    public Multiplicacao(Variavel[] operandos) {
        super(operandos);
    }

    @Override
    public double executa() {
        double result = getVariavel(0).getValor();
        for (int i = 1; i < getNumOperandos(); i++) {
            if(Utilitarios.eInt(result) && Utilitarios.eInt(getVariavel(0).getValor()))
                result = multiplicaEficiente(""+(int)result,""+(int)getVariavel(i).getValor());
            else
                result *= getVariavel(i).getValor();
        }
        return result;
    }
    
    
    /**
     * Efetua a multiplicação de dois números INTEIROS utilizando a forma
     * eficiente de papel aprendida na escola. não podem ser feitas
     * multiplicações, apenas somas e chamadas à tabuada.
     */
    private double multiplicaEficiente(String a, String b) {
    }
    
}
