/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package operacoes;

import memoria.Variavel;

/**
 * Classe que representa uma operação entre variáveis.
 *
 * @author clique
 */
public abstract class Operacao {
    /**
     * número de operandos desta operação.
     */
    private final int numOperandos;
    /**
     * Variáveis utilizadas nesta operação.
     */
    private final Variavel[] operandos;

    /**
     * Cria uma operação com a quantidade de operandos passada.
     * 
     * @param numOperandos quantidade de operandos.
     */
    public Operacao(int numOperandos) {
        this.numOperandos = numOperandos;
        this.operandos = new Variavel[numOperandos];
    }
    
    /**
     * Cria uma operação com os operandos passados.
     * 
     * @param operandos variáveis cujos valores serão utilizados na operação.
     */
    public Operacao(Variavel[] operandos) {
        this.numOperandos = operandos.length;
        this.operandos = operandos;
    }

    public int getNumOperandos() {
        return numOperandos;
    }
    
    /**
     * Retorna uma referência à variável na posição i;
     * 
     * @param i posição da variável
     * @return uma referência à variável na posição i;
     */
    protected Variavel getVariavel(int i) {
        return operandos[i];
    }
    
    /**
     * Altera o valor da variável na posição 'posicao' para o valor 'valor'.
     * 
     * @param posicao posição da variável
     * @param valor a ser armazenado
     */
    protected void setVariavel(int posicao, double valor){
        this.operandos[posicao].setValor(valor);
    }

    /**
     * Altera o valor da variável de nome 'nome' para o valor 'valor'. Não faz 
     * nada se a variável não estivar entre os operandos.
     * 
     * @param nome nome da variável
     * @param valor a ser armazenado
     */
    protected void setVariavel(String nome, double valor){
        int posicao = Variavel.busca(this.operandos,nome);
        if(posicao == -1) return;
        this.operandos[posicao].setValor(valor);
    }
    
    /**
     * Executa o cálculo associado à esta operação.
     * 
     * @return retorna o resultado final da aplicação desta operação, operando a
     * operando, da esquerda para a direita.
     */
    public abstract double executa();
    
    /**
     * Retorna uma instância da Operação correta, de acordo com o operador
     * passado, com os operandos passados.
     * 
     * 
     * @param operador operador que indica de qual operação a instância será
     * retornada
     * @param operandos Variáveis cujos valores serão utilizados no cálculo da 
     * operação.
     * @return uma instância da Operação correta, de acordo com o operador
     * passado, com os operandos passados. Caso o operador não seja conhecido, 
     * retorna null.
     */
    public static Operacao getOperacao(String operador, Variavel[] operandos) {
        switch(operador){
            case "+":
                return new Soma(operandos);
            case "-":
                return new Subtracao(operandos);
            case "/":
                return new Divisao(operandos);
            case "*":
                return new Multiplicacao(operandos);
            case "//":
                return new DivisaoInteira(operandos);
        }
        return null;
    }
}
