/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package operacoes;

import memoria.Variavel;

/**
 * Classe que implementa a operação de soma.
 *
 * @author clique
 */
public class Soma extends Operacao{
    
    public Soma(Variavel[] operandos) {
        super(operandos);
    }

    @Override
    public double executa() {
        double result = getVariavel(0).getValor();
        for (int i = 1; i < getNumOperandos(); i++) {
            result += getVariavel(i).getValor();
        }
        return result;
    }
}
